class Solution:
    def decompressRLElist(self, nums):
        decompressed = []
        for i in range(0, nums.length, 2):
            freq = nums[i]
            val = nums[i + 1]
            decompressed.extend([val] * freq)
        return decompressed

solution = Solution()
nums1 = [1, 2, 3, 4]
nums2 = [1, 1, 2, 3]

print(solution.decompressRLElist(nums1))  
print(solution.decompressRLElist(nums2))  
