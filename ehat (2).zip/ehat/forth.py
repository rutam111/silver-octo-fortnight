class Solution:
    def mostWordsFound(self, sentences):
        return max(len(sentence.split()) for sentence in sentences)

solution = Solution()
sentences1 = ["alice and bob love leetcode", "i think so too", "this is great thanks very much"]
sentences2 = ["please wait", "continue to fight", "continue to win"]

print(solution.mostWordsFound(sentences1))
print(solution.mostWordsFound(sentences2))
