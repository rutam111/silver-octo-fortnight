class Solution:
    def maximumWealth(self, accounts):
        max_wealth = 0
        for customer in accounts:
            wealth = sum(customer)
            max_wealth = max(max_wealth, wealth)
        return max_wealth

solution = Solution()
accounts1 = [[1, 2, 3], [3, 2, 1]]
accounts2 = [[1, 5], [7, 3], [3, 5]]
accounts3 = [[2, 8, 7], [7, 1, 3], [1, 9, 5]]

print(solution.maximumWealth(accounts1))  
print(solution.maximumWealth(accounts2))  
print(solution.maximumWealth(accounts3))
